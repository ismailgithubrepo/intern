const readlineSync = require("readline-sync")
const fs = require("node:fs/promises")


async function addData(){
    try{
    let data = await fs.readFile('/data1.json')
    data=Json.parse(data)
    const todo=readlineSync.question("give me a todo")
    data.push(todo)
    await fs.writeFile('./data.json')
    }
    catch(e){
        console.log(e)
    }
}