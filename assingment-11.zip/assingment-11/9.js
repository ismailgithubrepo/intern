const readlineSync = require("readline-sync")
const fs = require("node:fs")
const fs = require("node:fs/promise")


 async function addData() {
    let data = await fs.readFile('./data.json')
    const todo =  readlineSync.question('whats your name ')
    data = data+''+todo
    await fs.writeFile('data.json')
    console.log(String(data))
    }

    addData()