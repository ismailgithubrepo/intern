const readlineSync = require("readline-sync");
const fs = require("node:fs/promises");

async function deleteTodo() {
    try {
        // STEP 2: Ask user to choose an index
        const index = parseInt(readlineSync.question('Give me an index number: '), 10);

        // STEP 3: Read data.json
        let data = await fs.readFile('./data1.json');
        data = JSON.parse(data);

        // Ensure index is within the valid range
        if (index >= 0 && index < data.length) {
            // STEP 4: Delete that todo from data
            data.splice(index, 1);

            // STEP 5: Write the updated data back to data.json
            await fs.writeFile('./data1.json', JSON.stringify(data));
            console.log(`Todo item at index ${index} has been deleted.`);
        } else {
            console.log('Invalid index. No item deleted.');
        }
    } catch (error) {
        console.error('Error reading or writing the file:', error);
    }
}

deleteTodo();
