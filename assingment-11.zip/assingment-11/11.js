const readlineSync = require("readline-sync")
const fs = require("node:fs/promises")

async function addTodo(){
    try{
        let data = await fs.readFile('./data1.json')
        data = JSON.parse(data)
        const todo = readlineSync.question('give me a todo ')
        data.push({
            todo:todo,
            isDone:false
        })
        await fs.writeFile('./data1.json',JSON.stringify(data))
    }catch(e){
        console.log(e)
    }
}
addTodo()