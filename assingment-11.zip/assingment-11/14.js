const readlineSync = require("readline-sync");
const fs = require("node:fs/promises");

const express = require('express')
const app = express()
app.use(express.static('public'))
app.use(express.json())

app.get('/api/todo',async (req,res)=>{
    try{let data = await fs.readFile('./data1.json')
    data = JSON.parse(data)
    res.send(data)}
    catch(e){
        console.log(e)
    }
})
app.post('/api/todo',async (req,res)=>{
    const todo=req.body.todo
    let data = await fs.readFile('./data1.json')
    data = JSON.parse(data)
    data.push({
        todo:todo,
        isDone:false
    })
    await fs.writeFile('./data1.json',JSON.stringify(data))
    console.log(req.body)
    res.send("okay")
})
app.listen(3000,()=>{
    console.log("server listening on port 3000")
})