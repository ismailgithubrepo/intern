const readlineSync= require("readline-sync")

let userName = readlineSync.question('whats your name ')
console.log('your name is '+userName)