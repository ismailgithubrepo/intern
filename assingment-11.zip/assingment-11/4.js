let str=''

for(let i=0;i<100;i++){
    str=str+','+i
}
const fs = require("node:fs")

fs.writeFile('./test2.txt',str,(err)=>{
    console.log(err)}
)
