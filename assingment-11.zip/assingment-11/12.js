async function viewTodo(){
    // 0. shabbir
    // 1. CFI
    // 2. maker
    // STEP 1:
    let data = await fs.readFile('./data.json')
    data = JSON.parse(data)
    // console.log(data)
    // STEP 2: Format it
    for(let i=0;i<data.length;i++){
        console.log(i,data[i].todo,data[i].isDone)
    }
}