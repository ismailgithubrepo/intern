const readlineSync = require("readline-sync")
const fs = require("node:fs")
let userName = readlineSync.question('whats your name ')



function addData() {
    fs.readFile('./data.json', (err, data) => {
        data = String(data)
        data = data + ' ' + userName
        fs.writeFile('data.json', data, (err) => {
            console.log(err)
        })

    })
}
addData()