const readlineSync= require("readline-sync")

let n= readlineSync.question('wnter the number to print up to that number from 0 ')
for(let i=0;i<=n;i++){
console.log(i)}
