let code="for(let i=0;i<=100;i++){console.log(i)}"

const fs = require("node:fs")
fs.writeFile('f.js',code,(err)=>{
    console.log(err)}
)