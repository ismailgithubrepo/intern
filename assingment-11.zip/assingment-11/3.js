const fs = require("node:fs")

fs.writeFile('./test.txt',"tesing file system",(err)=>{
    console.log(err)}
)